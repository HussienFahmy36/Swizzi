//
//  Swizzi.h
//  Swizzi
//
//  Created by Hussien Gamal Mohammed on 5/20/19.
//  Copyright © 2019 MindValley. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Swizzi.
FOUNDATION_EXPORT double SwizziVersionNumber;

//! Project version string for Swizzi.
FOUNDATION_EXPORT const unsigned char SwizziVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Swizzi/PublicHeader.h>


